const db = require('../config/config');
const Direccion = {};

Direccion.create = (direccion, result) => {
    const sql1 = 
    `INSERT INTO direcciones
    (
        address, district, lat, lng, created_at, updated_at
    ) 
    VALUES (?, ?, ?, ?, ?, ?);
    `;
    
    const sql2 = 
    `UPDATE canchas set id_direccion = ? WHERE id = ?
    `;

    db.query(
        sql1,
        [
            direccion.address, direccion.district, direccion.lat, 
            direccion.lng, new Date(), new Date()
        ],
        (err, res) => {
            if (err) {
                console.log('Error: ', err);
                result(err, null);
            }
            else {
                const direccionId = res.insertId;
                console.log('ID de la dirección: ', direccionId);
                result(null, direccionId);
                db.query(
                    sql2,
                    [direccionId, direccion.id_cancha]
                )
            }
        }
    )
}

module.exports = Direccion;