import { AxiosError } from "axios";
import { Direccion } from "../../domain/entities/Direccion";
import { DireccionRepository } from "../../domain/repositories/DireccionRepository";
import { ApiFisiFutApp } from "../sources/remote/api/apiFisiFutApp";
import { ResponseFisiFutApp } from "../sources/remote/models/ResponseFisiFutApp";

export class DireccionRepositoryImpl implements DireccionRepository{
    async create(direccion: Direccion): Promise<ResponseFisiFutApp> {
        try{
            const response = await ApiFisiFutApp.post<ResponseFisiFutApp>('/direcciones/create', direccion);
            return Promise.resolve(response.data);
        }
        catch(error) {
            let e = (error as AxiosError);
            console.log('ERROR: ' + JSON.stringify(e.response?.data));
            const apiError: ResponseFisiFutApp = JSON.parse(JSON.stringify(e.response?.data));
            return Promise.resolve(apiError);
        }
    }
}