import { StackScreenProps } from '@react-navigation/stack';
import React, { useState, useEffect } from 'react'
import { Alert, ActivityIndicator, Image, Pressable, ScrollView, ToastAndroid, View } from 'react-native'
import { CustomTextInput } from '../../../../components/CustomTextInput';
import { ModalPickImage } from '../../../../components/ModalPickImage';
import { RoundedButton } from '../../../../components/RoundedButton';
import { CanchaStackParamList } from '../../../../navigator/CanchaCategoryNavigator';
import { MyColors, MyStyles } from '../../../../theme/AppTheme';
import styles from './Styles'
import useViewModel from './ViewModel';

interface Props extends StackScreenProps<CanchaStackParamList, 'CanchaAddressCreateScreen'>{};

export const CanchaAddressCreateScreen = ({navigation, route}: Props) => {
    const { address, district, refPoint , cliente, responseMessage, 
        loading, createDireccion, onChange} = useViewModel();
    const [modalVisible, setModalVisible] = useState(false);

    useEffect(() => {
        if (route.params?.refPoint){
            onChange('refPoint', route.params?.refPoint);
        }
    }, [route.params?.refPoint])
    
    useEffect(() => {
        if (route.params?.latitude){
            onChange('lat', route.params?.latitude);
        }
    }, [route.params?.latitude])

    useEffect(() => {
        if (route.params?.longitude){
            onChange('lng', route.params?.longitude);
        }
    }, [route.params?.longitude])

    useEffect(() => {
        if (responseMessage !== ''){
            ToastAndroid.show(responseMessage, ToastAndroid.LONG);
        }
    }, [responseMessage])

    return (
        <View style={styles.container}>
            <View style={styles.logoContainer}>
                <Pressable onPress={() => setModalVisible(true)}>
                    <Image 
                        style={styles.logoImage}
                        source={require('../../../../../../assets/map.png')}
                    />
                </Pressable>
            </View>

            <View style={styles.form}>
                <CustomTextInput
                    placeholder='Dirección'
                    image={require('../../../../../../assets/direccion.png')}
                    keyboardType='default'
                    property='address'
                    value={address}
                    onChangeText={ onChange }
                />

                <CustomTextInput
                    placeholder='Distrito'
                    image={require('../../../../../../assets/distrito.png')}
                    keyboardType='default'
                    property='district'
                    value={district}
                    onChangeText={ onChange }
                />

                <Pressable
                    onPress={() => navigation.navigate('CanchaAddressMapScreen')}
                >
                    <CustomTextInput
                        placeholder='Punto de referencia'
                        image={require('../../../../../../assets/referencia.png')}
                        keyboardType='default'
                        property='refPoint'
                        value={refPoint}
                        onChangeText={ onChange }
                        editable={false}
                    />
                </Pressable>

                <View style={styles.buttonContainer}>
                <RoundedButton
                    text='Crear dirección'
                    onPress={() => {}}
                />
                </View>
            </View>

            {
                loading &&
                <ActivityIndicator 
                    style={MyStyles.loading} 
                    size="large" 
                    color={MyColors.defaultText} 
                />
            }
        </View>
    )
}