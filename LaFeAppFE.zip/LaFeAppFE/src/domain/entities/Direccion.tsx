export interface Direccion {
    id?: string;
    address: string;
    district: string;
    lat: number,
    lng: number,
    id_cancha: string
}