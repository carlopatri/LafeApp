export interface Rol {
    id: string,
    name: string,
    image: string
}